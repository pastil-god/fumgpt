export type NewsArticle = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  body: string;
  imageUrl?: string;
  videoUrl?: string;
  publishedAt: string;
  isFeatured?: boolean;
  status?: "active" | "draft";
  ctaLabel?: string;
  ctaHref?: string;
  priority?: number;
};

export const newsArticles: NewsArticle[] = [
  {
    id: "news-001",
    slug: "launch-of-fumgpt-premium-marketplace",
    title: "لانچ نسخه جدید فروشگاه FumGPT با ساختار حرفه‌ای‌تر",
    excerpt:
      "نسخه جدید صفحه اصلی با تمرکز روی اعتمادسازی، شلف محصولات و مسیر توسعه آکادمی و بازارچه ایجنت منتشر شد.",
    body:
      "در این به‌روزرسانی، صفحه اصلی فروشگاه FumGPT از یک لندینگ ساده به یک ویترین حرفه‌ای‌تر تبدیل شده است. چینش جدید روی معرفی سریع دسته‌ها، نمایش پیشنهادهای منتخب و آماده‌سازی ساختار سایت برای افزودن آکادمی و بازارچه ایجنت تمرکز دارد.",
    publishedAt: "2026-04-18T09:00:00.000Z",
    isFeatured: true
  },
  {
    id: "news-002",
    slug: "content-management-ready-for-products-and-media",
    title: "زیرساخت مدیریت محتوا برای محصولات، خبرها و مدیا آماده شد",
    excerpt:
      "اکنون می‌توان ساختار سایت را به CMS متصل کرد تا مدیر محتوا بدون نیاز به کدنویسی، محصول و خبر جدید ثبت کند.",
    body:
      "این فاز روی جداسازی لایه محتوا از رابط کاربری تمرکز دارد تا داده‌های محصولات، تصاویر، ویدئوها و خبرها از طریق یک داشبورد مدیریت شوند. به این ترتیب تیم محتوا می‌تواند بدون درگیری با کد، اطلاعات جدید را منتشر کند.",
    publishedAt: "2026-04-16T11:30:00.000Z"
  },
  {
    id: "news-003",
    slug: "next-phase-roadmap-for-academy-and-agents",
    title: "نقشه راه فاز بعد: آکادمی، محتوای آموزشی و بازارچه ایجنت",
    excerpt:
      "معماری فعلی طوری چیده شده که در فاز بعد بتوان خبرها، آموزش‌ها و ایجنت‌ها را روی همین پایه گسترش داد.",
    body:
      "طراحی و ساختار فعلی سایت فقط برای لانچ اولیه نیست. از همین حالا مسیر توسعه برای خبرها، آموزش‌های تخصصی، فروشنده‌ها و محصولات جدید باز گذاشته شده است تا رشد بعدی با حداقل بازطراحی انجام شود.",
    publishedAt: "2026-04-12T14:15:00.000Z"
  }
];
